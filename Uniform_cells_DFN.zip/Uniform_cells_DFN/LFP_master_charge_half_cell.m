function LFP_master_charge_half_cell
%% Code by Eloise Tredenick 2023, University of Oxford from MDFN
%% The following paper must be cited when using or modifying this code - Tredenick et al 2024 J. Electrochem. Soc. https://doi.org/10.1149/1945-7111/ad5767

%3C charge
N_r = 43;  %number of nodes in r, has to be odd
N  = 65;  %number of nodes in x, has to be odd

% %faster version for testing
% N_r = 27;  %number of nodes in r, has to be odd
% N  = 27;  %number of nodes in x, has to be odd

%% Parameters for LFP
capacity005C = 150; %Experimental capacity at 0.05C in mAh/g
cell_weightNMCLFP = 0.0367; %weight of battery in g

Rc = 14  ; %Resistance

%% Cathode OCP
V_0_cs0 = 2.9;  % Initial voltage charge
%V_0_cs0 = 4;  % Initial voltage discharge
U_Discharge = @(y)  3.413025424326315 + 0.001./y + 0.001./(y-1) ; % OCP  - see Supplementary Materials, Figure 2 for experimental data and fit.    
lhs = 1000 * (V_0_cs0 - 3.413025424326315 ); %OCP rearranged to find y part 1
SOC0 =   (- sqrt (lhs ^2 +4) + lhs + 2 )/(2*lhs); %%OCP rearranged to find y=SOC

c_rate = 3; %C rate
mAh =  5.505026; %current in mAh
current_A = mAh * c_rate *1e-3 ; % Current in Amps 
Area_electrode	= 1.54e-4; %Area of electrode in m^2
i_app =  current_A/Area_electrode; %Applied current in A/m^2

sigma_s_cathode =  5; %Electronic conductivity in solid in S/m
k_cath_ref = 2e-11 ; %Reaction rate constant in m^{2.5}s^{-1}mol^{-0.5}

v_max = 4.2; %Maximum allowed voltage when charging
%v_min = 2.5; %Minimum allowed voltage when  discharging 

tplus = 0.37; %t plus parameter

Dscath_bulk = 6e-16; %Diffusivity of Li ions in solid in m^2/s

eps_e_s = 0.45; %Porosity of sep
eps_e_cathode = 0.2625; %Porosity cathode
eps_CBD = 0.08  ; %CBD volume fraction

brugg_cath = 1.88 ; %Tortuosity of cathode
bruggs = 1.5; % Tortuosity of sep

Rscathode =  4.283e-7; %Radius of cathode solid particles in m

%% CONSTANTS AND TEMPERATURE
R = 8.31446261815324; %Gas constant 2019 [Pa m^3/ (K mol)]
Fara = 96485.33212; % Faraday constant [C.mol-1] 2019
Temp_c = 20; 
T_ref = Temp_c + 273.15;           % Reference temperature [K]

I_sign = 1; %Sign of current. -1 when discharging, +1 when charging

Ns = N  - 2; %cs doesn't get evaluated at boundaries of x
N2 = Ns * N_r; %number of nodes for cs through x and r
t0 = 0;
tf = 12*60*60; %simulation end time in seconds
tspan1 = [t0 tf];

Ls = 16e-6;  %Thickness of sep in m
Lcathode = 108e-6; %Thickness of cathode in m

L	= Lcathode + Ls ; 	% Thickness of the cell in m

%% Typical values - used for non-dimensionalisation
D_char_e = 5.34e-10; % Typical De in m^2/s
Kappa_char = 1; %Typical kappa in S/m
c_char = 1e3; %Typical value of lithium-ion concentration in electrolyte in mol/m3
ce0 = c_char;

%% De and kappa e functions
p1 =   -7.55e-21 ;
p2 =   8.231e-17 ;
p3 =  -3.401e-13 ;
p4 =   5.464e-10 ;
De_bulk_fun = @(cebar) p1.*(cebar.*ce0).^3 + p2.*(cebar.*ce0).^2 + p3.*(cebar.*ce0) + p4 ;

q1 =   5.746e-18  ;
q2 =  -1.025e-13  ;
q3 =   7.082e-10 ;
q4 =  -2.236e-06  ;
q5 =     0.00273 ;
q6 =   -0.003002  ;
Ke_bulk_fun =  @(cebar) q1.*(cebar .* ce0).^5 + q2.*(cebar .* ce0).^4 + q3.*(cebar .* ce0).^3 + q4.*(cebar .* ce0).^2 + q5.*(cebar .* ce0) + q6;

%% INITIAL CONDITIONS & CONCENTRATIONS
cs_cath_max = 22806;  %maximum cs
cs_cath_0 = cs_cath_max*SOC0;
a_cath = 3 * (1 - eps_e_cathode - eps_CBD) /Rscathode ;

%% Mesh - ions - need to use at faces for control volume and functions - nondim
nodes_s = linspace((Lcathode/L),  1, N);
dx_s = nodes_s(2) - nodes_s(1);
faces_s = ([nodes_s(1) nodes_s] + [nodes_s nodes_s(end)]) ./ 2;
Dx_s = diff(faces_s(:));        % distance between faces

nodes_p = linspace(0, (Lcathode/L), N);
dx_p = nodes_p(2) - nodes_p(1);
faces_p = ([nodes_p(1) nodes_p] + [nodes_p nodes_p(end)]) ./ 2;
Dx_p = diff(faces_p(:));        % distance between faces

%% Mesh - rp
nodesRp = linspace(0 , 1 , N_r);
drp = nodesRp(2) - nodesRp(1);

%Dimensional nodes
nodesdimRp = nodesRp .* Rscathode;
nodes_sep = nodes_s .* L;
nodes_cath = nodes_p .* L; 
nodes_dim = [ nodes_cath nodes_sep ];

%% Dimensionless Groupings and constants
taud = L^2 / D_char_e;
tspan_nodim1 = tspan1 ./ taud;
FRT = Fara / (R * T_ref);
U = 2* L * a_cath * k_cath_ref * c_char^0.5 * cs_cath_max *Fara/ i_app;
B = taud * Dscath_bulk / (Rscathode^2);
Ff = i_app * Rscathode / (L * Fara * a_cath * Dscath_bulk * cs_cath_max);
H = i_app * Fara * L/ (sigma_s_cathode * R * T_ref );
Ip = Fara * i_app * L / (R * T_ref * sigma_s_cathode);
P = 2 * (1 - tplus);
Ss = i_app * L * Fara / (R * T_ref * Kappa_char);
kap_p = eps_e_cathode .^ brugg_cath ./Kappa_char ;
kap_s = eps_e_s .^ bruggs ./Kappa_char;
Dep_paras = eps_e_cathode .^ brugg_cath ./D_char_e ;
Des_paras = eps_e_s .^ bruggs ./D_char_e ;
S_LP = (1 - tplus) * i_app * L / ( Fara * D_char_e * c_char );
Mm = (1 - tplus) * L * i_app / (D_char_e * Fara * eps_e_cathode * c_char) ;

%% Dimensionless initial conditions
c_bar_s_p0 =  cs_cath_0 ./ cs_cath_max .* ones(1, N2);
c_bar_s_p_surf00 = c_bar_s_p0(end);
c_bar_e_p0 = ce0./c_char.* ones(1, N);
c_bar_e_s0 = ce0./c_char.* ones(1, N);
phi_bar_ep0 = zeros(1, N);
phi_bar_es0 = zeros(1, N);

Ucathodebar0 =  FRT .* U_Discharge(c_bar_s_p_surf00);
phi_bar_sp0 = Ucathodebar0 .* ones(1, N);
%BV
Jbarcathode0 =  U .* sqrt(c_bar_e_p0(2:N-1) .* c_bar_s_p_surf00 .* (1 - c_bar_s_p_surf00))  .* sinh( 0.5 .* (phi_bar_sp0(2:N-1) - phi_bar_ep0(2:N-1)  - Ucathodebar0));

%Collect ICs
ICs_0_orig = [c_bar_s_p0 phi_bar_sp0 phi_bar_ep0 phi_bar_es0 c_bar_e_p0 c_bar_e_s0 Jbarcathode0];

%Make M the mass matrix for ODE15s - specifies where the time derivatives are located including the BCs (0 is no derivative).
%for cs
D_pat_xrd = eye(N2, N2);
for ii = 1:Ns
    D_pat_xrd(ii*N_r - (N_r-1),ii*N_r - (N_r-1)) = 0;
    D_pat_xrd(N_r*ii,N_r*ii) = 0;
end
%for ce 
D_pat_x1 = eye(N, N);
D_pat_x1(1,1) = 0;
D_pat_x1(end,end) = 0;

icL = length(ICs_0_orig);
M = sparse(icL,icL);

M(1:N2,1:N2) = D_pat_xrd;
M(1 * N2 + 3 * N  + 1 : 1 * N2 + 4 * N, 1 * N2 + 3 * N  + 1 : 1 * N2 + 4 * N) = D_pat_x1;
M(1 * N2 + 4 * N  + 1 : 1 * N2 + 5 * N,  1 * N2 + 4 * N  + 1 : 1 * N2 + 5 * N ) = D_pat_x1;

%% Setup options for solving 
reltol = 1e-6;
abstol = 1e-7;
opts = odeset('RelTol',reltol,'AbsTol', abstol ,'Mass',M,'Events', @(t,phi_sol) DFN_event(t,phi_sol));
%% use if testing at N=27 for faster version
%opts = odeset('Mass',M,'Stats','on', 'Events', @(t,phi_sol) DFN_event(t,phi_sol));

%% Solve the RHS system (code at end)
[t_sol,phi_solution] = ode15s(@rhs,tspan_nodim1, ICs_0_orig, opts);

%% Extract the solution -nondim
csp_nondim =     phi_solution(:, 1 : N2);
phiphisp_nondim= phi_solution(:, 1 * N2 + 1 : 1 * N2 + N);
phiep_nondim   =  phi_solution(:, 1 * N2 + N  + 1 : 1 * N2 + 2 * N);
phies_nondim = phi_solution(:, 1 * N2 + 2 * N  + 1 : 1 * N2 + 3 * N );
cep_nondim =      phi_solution(:, 1 * N2 + 3 * N  + 1 : 1 * N2 + 4 * N );
ces_nondim  =     phi_solution(:, 1 * N2 + 4 * N  + 1 : 1 * N2 + 5 * N );
Jbarc =           phi_solution(:, 1 * N2 + 5 * N  + 1 : 1 * N2 + 5 * N +  Ns);

% Dimensionalise 
Csp_dim = cs_cath_max .* csp_nondim;
phiep_dim =    phiep_nondim./ FRT;
phies_dim =   phies_nondim./ FRT;
J_cathode_plot = Jbarc .* (i_app / (L * a_cath));
cep_dim = c_char  .*  cep_nondim;
ces_dim = c_char  .*  ces_nondim;
phiphisp_dim =  (R * T_ref / Fara).* phiphisp_nondim;

%plotting parameters
time_steps = length(t_sol(1:end,1));
num_plots = 15;
every = round(time_steps / num_plots);
fontsize = 20;
markersize = 12;
linewidth = 4;

%% Calc cs
csp_surf = zeros(time_steps,Ns);
csp_centre = zeros(time_steps,Ns);
for ii = 1:Ns
    csp_surf(:,ii) = Csp_dim(:,N_r*ii);
    csp_centre(:,ii) = Csp_dim(:,ii*N_r - (N_r-1));
end
ratio_psurf = 1- csp_surf ./ cs_cath_max ;
ratio_p_centre = 1- csp_centre ./ cs_cath_max ;

%%cs
cpoverRXprelim = zeros(time_steps,Ns);
for tt = 1:time_steps
    for ii = 1:Ns
        cp =  nodesdimRp.^2 .*csp_nondim(tt,(  ii*N_r - (N_r-1) : N_r*ii));
        cpoverRXprelim(tt,ii)  = 3 ./ ( Rscathode^3)  .* trapz(nodesdimRp,cp);
    end
end

phiep0real = phi_bar_ep0 ./ FRT;
phies0real = phi_bar_es0./ FRT;
phis0real = phi_bar_sp0./ FRT;

t_sec = taud .* t_sol;
V_cell = phiphisp_dim(:,1) + Rc*current_A* I_sign;

cap_mAhg = current_A .* t_sec * 1e3./ ( 3600 * cell_weightNMCLFP);
cap_norm = cap_mAhg ./capacity005C;

cs_surf_bar = csp_surf./cs_cath_max';
nodes_nondim_plotterLFP = linspace(0,1,N-2);

ratp_ccSURF=ratio_psurf(:,1);
ratpsepSURF=ratio_psurf(:,end);
ratp_cc_centre=ratio_p_centre(:,1);
ratpsep_centre=ratio_p_centre(:,end);

%% Plot results

%phis
figure;
colmat = parula(num_plots+7);
subplot(1,2,1);
set(gcf,'DefaultAxesColorOrder',colmat)
plot113 = plot(nodes_cath./1e-6, phis0real', '-kx', 'MarkerSize', markersize,'LineWidth', linewidth);hold all;
plot(nodes_cath./1e-6, phiphisp_dim(1:every:end,:)', 'LineWidth', linewidth);
plot443 = plot(nodes_cath./1e-6, phiphisp_dim(end,:)', 'LineWidth', linewidth);
set(legend([ plot113 plot443],{'Initial condition','Final solution'}, 'Location','best'), 'FontSize',12,'FontName','Times New Roman');
set(xlabel('x_{p} (\mum)'), 'FontSize', fontsize,'FontName','Times New Roman');
set(ylabel('\phi_s (V)'), 'FontSize', fontsize,'FontName','Times New Roman');
set(gca,'FontSize',fontsize,'FontName','Times New Roman');

subplot(1,2,2);
plot(t_sec, phiphisp_dim(:,1)','MarkerSize', markersize,'LineWidth', linewidth);hold all;
plot(t_sec, phiphisp_dim(:,end)', '-b', 'MarkerSize', markersize,'LineWidth', linewidth);
set(xlabel('Time (s)'), 'FontSize', fontsize,'FontName','Times New Roman');
set(ylabel('\phi_{s} (V)'), 'FontSize', fontsize,'FontName','Times New Roman');
set(legend('CC','Sep', 'Location','best'), 'FontSize',12,'FontName','Times New Roman');
set(gca,'FontSize',fontsize,'FontName','Times New Roman');

%J
figure;
colmat = parula(num_plots+7);
subplot(2,2,1);
set(gcf,'DefaultAxesColorOrder',colmat)
plot113 = plot(nodes_cath(2:N-1)./1e-6, J_cathode_plot(1,:)', '-kx', 'MarkerSize', markersize,'LineWidth', linewidth);hold all;
plot(nodes_cath(2:N-1)./1e-6, J_cathode_plot(1:every:end,:)', 'LineWidth', linewidth);
plot443 = plot(nodes_cath(2:N-1)./1e-6, J_cathode_plot(end,:)', 'LineWidth', linewidth);
set(xlabel('x_{p} - \mum'), 'FontSize', fontsize,'FontName','Times New Roman');
set(ylabel('J_{p} - A/m^2'), 'FontSize', fontsize,'FontName','Times New Roman');
set(legend([ plot113 plot443],{'Initial condition','Final solution'}, 'Location','best'), 'FontSize',12,'FontName','Times New Roman');
set(gca,'FontSize',fontsize,'FontName','Times New Roman');

colmat = parula(6);
subplot(2,2,2);
set(gcf,'DefaultAxesColorOrder',colmat)
plotsep = plot(t_sec, ratpsepSURF', 'LineWidth', linewidth,'color', colmat(1,:));hold all;
plotsep1 = plot(t_sec, ratpsep_centre', 'LineWidth', linewidth,'color', colmat(2,:));
plotcc = plot(t_sec, ratp_ccSURF', 'LineWidth', linewidth,'color', colmat(4,:));
plotcc1 = plot(t_sec, ratp_cc_centre', 'LineWidth', linewidth,'color', colmat(5,:));
set(xlabel('Time (s)'), 'FontSize', fontsize,'FontName','Times New Roman');
set(ylabel('1 - c_{s,p}/c_{s,p}^{max}'), 'FontSize', fontsize,'FontName','Times New Roman');
set(legend([plotsep plotsep1 plotcc plotcc1 ],{'Sep_{surf}','Sep_{centre}','CC_{surf}','CC_{centre}'}, 'Location','best'), 'FontSize',8);
set(gca, 'FontSize', fontsize);

%Plot cs surf
subplot(2,2,3);
colmat = parula(num_plots+7);
set(gcf,'DefaultAxesColorOrder',colmat)
plot113=plot(nodes_nondim_plotterLFP, cs_surf_bar(1,:), '-kx', 'MarkerSize', markersize,'LineWidth', linewidth);hold all;
plot(nodes_nondim_plotterLFP, cs_surf_bar(1:every:end,:), 'LineWidth', linewidth);
plot443=plot(nodes_nondim_plotterLFP, cs_surf_bar(end,:), 'LineWidth', linewidth);
set(xlabel('x'), 'FontSize', fontsize,'FontName','Times New Roman');
set(ylabel('c_{s,p,surf}/c_{s,p}^{max}'), 'FontSize', fontsize,'FontName','Times New Roman');
axis([0 1 0 1 ]);ax = gca;ax.YTick =linspace(0, 1 ,5);
set(legend([ plot113 plot443],{'Initial condition','Final solution'}, 'Location','best'), 'FontSize',12,'FontName','Times New Roman');
set(gca,'FontSize',fontsize,'FontName','Times New Roman');

%% Plot all ce and phie together
% ce
fontsizeL = 12;
colmat = parula(num_plots+6);
figure;
subplot(4,1,1);
set(gcf,'DefaultAxesColorOrder',colmat)
plot113 = plot(nodes_dim./1e-6,[ ces_dim(1,1:end)'; cep_dim(1,1:end)']  , '-kx', 'MarkerSize', markersize,'LineWidth', linewidth);hold all;
plot(nodes_dim./1e-6, [cep_dim(1:every:end,:)'; ces_dim(1:every:end,:)'], 'LineWidth', linewidth);
plot443 = plot(nodes_dim./1e-6,[cep_dim(end,1:end)'; ces_dim(end,1:end)'], 'LineWidth', linewidth);
set(xlabel('x - \mum'), 'FontSize', fontsize,'FontName','Times New Roman');
set(ylabel('c_e - mol/m^3'), 'FontSize', 6,'FontName','Times New Roman');
set(legend([ plot113 plot443],{'Initial condition','Final solution'}, 'Location','best'), 'FontSize',fontsizeL,'FontName','Times New Roman');
set(gca,'FontSize',fontsize,'FontName','Times New Roman');

subplot(4,2,3);
set(gcf,'DefaultAxesColorOrder',colmat)
plot(t_sec, cep_dim(:,1)',  'MarkerSize', markersize,'LineWidth', linewidth);hold all;
plot(t_sec, cep_dim(:,end)', '-b', 'MarkerSize', markersize,'LineWidth', linewidth);
set(xlabel('time - s'), 'FontSize', fontsize,'FontName','Times New Roman');
set(ylabel('c_{e,p} - mol/m^3'), 'FontSize', fontsize,'FontName','Times New Roman');
set(legend('CC','Sep', 'Location','best'), 'FontSize',fontsizeL,'FontName','Times New Roman');
set(gca,'FontSize',fontsize,'FontName','Times New Roman');

subplot(4,2,4);
set(gcf,'DefaultAxesColorOrder',colmat)
plot(t_sec, ces_dim(:,1)', 'MarkerSize', markersize,'LineWidth', linewidth);hold all;
plot(t_sec, ces_dim(:,end)', '-b', 'MarkerSize', markersize,'LineWidth', linewidth);
set(xlabel('time - s'), 'FontSize', fontsize,'FontName','Times New Roman');
set(ylabel('c_{e,s} - mol/m^3'), 'FontSize', 6,'FontName','Times New Roman');
set(legend('L','R', 'Location','best'), 'FontSize',fontsizeL,'FontName','Times New Roman');
set(gca,'FontSize',fontsize,'FontName','Times New Roman');

% phie
subplot(4,1,3);
set(gcf,'DefaultAxesColorOrder',colmat)
plot110 = plot(nodes_dim./1e-6, [phiep0real'; phies0real']  , '-o', 'MarkerSize', markersize,'LineWidth', linewidth);hold all;
plot(nodes_dim./1e-6, [phiep_dim(1:every:end,:)'; phies_dim(1:every:end,:)'; ], 'LineWidth', linewidth);
plot4435 = plot(nodes_dim./1e-6,[phiep_dim(end,1:end)'; phies_dim(end,1:end)'; ], 'LineWidth', linewidth);
set(xlabel('x - \mum'), 'FontSize', fontsize,'FontName','Times New Roman');
set(ylabel('\phi_e - V'), 'FontSize', fontsize,'FontName','Times New Roman');
set(legend([ plot110 plot4435],{'Initial condition','Final solution'}, 'Location','best'), 'FontSize',fontsizeL,'FontName','Times New Roman');
set(gca,'FontSize',fontsize,'FontName','Times New Roman');

subplot(4,2,7);
set(gcf,'DefaultAxesColorOrder',colmat)
plot(t_sec, phiep_dim(:,1)', 'MarkerSize', markersize,'LineWidth', linewidth);hold all;
plot(t_sec, phiep_dim(:,end)', '-b', 'MarkerSize', markersize,'LineWidth', linewidth);
set(xlabel('time - s'), 'FontSize', fontsize,'FontName','Times New Roman');
set(ylabel('\phi_{e,p} - V'), 'FontSize', fontsize,'FontName','Times New Roman');
set(legend('CC','Sep', 'Location','best'), 'FontSize',fontsizeL,'FontName','Times New Roman');
set(gca,'FontSize',fontsize,'FontName','Times New Roman');

subplot(4,2,8);
set(gcf,'DefaultAxesColorOrder',colmat)
plot(t_sec, phies_dim(:,1)','MarkerSize', markersize,'LineWidth', linewidth);hold all;
plot(t_sec, phies_dim(:,end)', '-b', 'MarkerSize', markersize,'LineWidth', linewidth);
set(xlabel('time - s'), 'FontSize', fontsize,'FontName','Times New Roman');
set(ylabel('\phi_{e,s} - V'), 'FontSize', fontsize,'FontName','Times New Roman');
set(legend('L','R', 'Location','best'), 'FontSize',fontsizeL,'FontName','Times New Roman');
set(gca,'FontSize',fontsize,'FontName','Times New Roman');

%% Plot voltage vs capacity and time
colmat = parula(6);
figure;
set(gcf,'DefaultAxesColorOrder',colmat)
plot(cap_norm, V_cell, 'LineWidth', linewidth,'color', colmat(1,:));hold all;
set(xlabel('Normalilsed Capacity'), 'FontSize', fontsize);
set(ylabel('Voltage (V)'), 'FontSize', fontsize);
set(gca,'FontSize',fontsize,'FontName','Times New Roman');

figure;
set(gcf,'DefaultAxesColorOrder',colmat)
plot(t_sec, V_cell, 'LineWidth', linewidth,'color', colmat(1,:));hold all;
set(xlabel('Time (s)'), 'FontSize', fontsize);
set(ylabel('Voltage (V)'), 'FontSize', fontsize);
set(gca,'FontSize',fontsize,'FontName','Times New Roman');

    function out = rhs(~, X)
        %% Initialise time derivatives and functions
        csp_dt = zeros(N2, 1);
        cscathode_surf = zeros(Ns, 1);
        Fphiep= zeros(N, 1);
        Fphies = zeros(N, 1);
        cep_dt= zeros(N, 1);
        ces_dt= zeros(N, 1);
        Fphisp= zeros(N, 1);

        %% Vectors of PDE quantities
        cscathode = X(1 : N2,1);
        phisp = X( N2 + 1 : N2 + N,1);
        phiep =  X(  N2 + N  + 1 :  N2 + 2 * N ,1);
        phies =  X( N2 + 2 * N  + 1 :  N2 + 3 * N  ,1);
        cep =  X( N2 + 3 * N  + 1 :  N2 + 4 * N,1 );
        ces =  X( N2 + 4 * N  + 1 :  N2 + 5 * N,1 );
        Jbarcathode = X( N2 + 5 * N  + 1 :  N2 + 5 * N +  Ns ,1);

        %% Fluxes and at faces
        grad_phisp = diff(phisp) ./ dx_p;

        Kappa_e_p_bar = kap_p .* Ke_bulk_fun(cep);
        Kappa_e_s_bar = kap_s .* Ke_bulk_fun(ces) ;

        Kappa_p_faces =(Kappa_e_p_bar(2:N) + Kappa_e_p_bar(1:N-1)) ./ 2;
        Kappa_s_faces =(Kappa_e_s_bar(2:N) + Kappa_e_s_bar(1:N-1)) ./ 2;

        grad_phiep = diff(phiep) ./ dx_p;
        flux_phiep = - Kappa_p_faces .* grad_phiep;
        gradlogcep = diff(cep) ./( dx_p .*cep(2:N));
        fluxceplog = -  Kappa_p_faces .* P .* gradlogcep;

        grad_phies = diff(phies) ./ dx_s;
        flux_phies = - Kappa_s_faces .* grad_phies ;
        gradlogces = diff(ces) ./( dx_s .*ces(2:N));
        fluxceslog = -  Kappa_s_faces .* P .* gradlogces;

        D_e_p_bar = Dep_paras .* De_bulk_fun(cep);
        D_e_s_bar = Des_paras .* De_bulk_fun(ces) ;

        De_p_faces =(D_e_p_bar(2:N) + D_e_p_bar(1:N-1)) ./ 2;
        De_s_faces =(D_e_s_bar(2:N) + D_e_s_bar(1:N-1)) ./ 2;
        grad_cep = diff(cep) ./ dx_p;
        flux_cep = - De_p_faces .* grad_cep;
        grad_ces = diff(ces) ./ dx_s;
        flux_ces = - De_s_faces .* grad_ces ;

        %% csp - at each x and r point/ P2D
        for nn = 1:Ns
            grad_csp = diff(cscathode(nn*N_r - (N_r-1): N_r*nn) ) ./ drp;
            csp_dt((nn*N_r - (N_r-2)):N_r*nn-1) =- B .* diff(-(nodesRp(2:N_r)').^2 .* grad_csp)./ (drp .* (nodesRp(2:N_r-1)').^2) ;
            csp_dt(nn*N_r - (N_r-1)) = grad_csp(1) ;
            csp_dt(N_r*nn) = grad_csp(N_r-1) + Ff * Jbarcathode(nn);
            cscathode_surf(nn,1) = cscathode(N_r*nn,1);
        end

        %% phis
        Fphisp(2:N-1) = diff(grad_phisp)./ dx_p - H.*Jbarcathode;
        Fphisp(1) = grad_phisp(1) + Ip * I_sign;
        Fphisp(N) =  grad_phisp(N-1);

        %% cep
        cep_dt(2:N-1) = - 1./eps_e_cathode .* diff(flux_cep)./ Dx_p(2:N-1) + Mm .* Jbarcathode; 
        cep_dt(1) = grad_cep(1) ;
        cep_dt(N) = cep(N) -  ces(1) ;

        %% ces
        ces_dt(2:N-1) = - 1./eps_e_s .* diff(flux_ces)./ Dx_s(2:N-1) ;
        ces_dt(1) = flux_ces(1) - flux_cep(N-1); 
        ces_dt(N) = flux_ces(N-1) - S_LP * I_sign ;  

        %% phiep
        Fphiep(2:N-1) = diff(- flux_phiep + fluxceplog)./ Dx_p(2:N-1) + Ss .* Jbarcathode ;
        Fphiep(1) = grad_phiep(1) ;
        Fphiep(N) = phies(1) - phiep(N);

        %% phies
        Fphies(2:N-1) =  diff(-flux_phies + fluxceslog)./ Dx_s(2:N-1) ;
        Fphies(1) =  - flux_phies(1) + fluxceslog(1) + Ss * I_sign;
        Fphies(N) =  phies(N);

        %% U and J functions
        Ucathodebar =  FRT .* U_Discharge(cscathode_surf);
        FJp  = Jbarcathode  -   U .* sqrt(cep(2:N-1)  .* cscathode_surf  .* (1 - cscathode_surf )) .* sinh( 0.5 .* (phisp(2:N-1) - phiep(2:N-1)   - Ucathodebar));

        %% Collect derivatives and Functions
        out = [csp_dt;   Fphisp;  Fphiep; Fphies; cep_dt; ces_dt;  FJp];
    end

%% Charge
    function [value,isterminal,direction] = DFN_event(~,phi_sol)
        %cs
        value(1)        =   real(max(phi_sol(1 : N2)))   ;
        isterminal(1)    =  1;
        direction(1)     =  -1;
        %V
        Vevent = (R * T_ref / Fara) *  real(phi_sol(N2 + 1)) + Rc*current_A* I_sign;
        value(2)         = v_max - Vevent; %when charging
        isterminal(2)   =   1;
        direction(2)    =   -1;
        %ce
        ce_all   = phi_sol(  N2 + 3 * N  + 1 : N2 + 5 * N).*ce0;
        value(3) = all(ce_all > 0);
        isterminal(3) = 1;
        direction(3) = -1;
    end

%% Discharge
%     function [value,isterminal,direction] = DFN_event(~,phi_sol)
%         %value is what you want to be zero to exit
%         %cs
%         value(1)        =  end_tol_csmax - real(max(phi_sol(1 : N2)))   ; 
%         isterminal(1)    =  1;
%         direction(1)     =  -1;
%         %V
%         Vevent = (R * T_ref / Fara) *  real(phi_sol(N2 + 1))+ Rc*current_A* I_sign;
%         value(2)        =  Vevent  - v_min;%when discharging
%         isterminal(2)   =   1;
%         direction(2)    =   -1;
%         %ce
%         ce_p_with_s   = phi_sol(  N2 + 3 * N  + 1 : N2 + 5 * N)*ce0;
%         value(3) = all(ce_p_with_s > 0);
%         isterminal(3) = 1;
%         direction(3) = -1;
%     end
end